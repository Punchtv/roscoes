#Python 2.7.10 (default, May 23 2015, 09:40:32) [MSC v.1500 32 bit (Intel)] on win32
#Type "copyright", "credits" or "license()" for more information.
#>>> ================================ RESTART ================================
#>>> 
#                                                   #
#           PUNCH TV OFFICIAL KODI PLUGIN           #
#         developed by Theuk_MadHatter /\/\         #
#           www.fiverr.com/theuk_madhatter          #
#    All rights and content belong to Punch TV .inc #
#                                                   #
#---------------------------------------------------#

import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
import urllib2
import re
import json
import base64
import time
import plugintools
import webbrowser

from operator import itemgetter

IiII1IiiIiI1 = 'plugin.video.roscoes'
iIiiiI1IiI1I1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , IiII1IiiIiI1 , 'images/' ) ) ;
punchtv =  xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , IiII1IiiIiI1 , 'punchtv.STRM' ) ) ;
o0OoOoOO00 = "[COLOR white][B]PUNCH[/B][/COLOR] [COLOR red]TV[/COLOR] [COLOR white][B]STUDIOS[/B][/COLOR]"
I11i = iIiiiI1IiI1I1 + 'fanart.jpg'
O0O = "http://69.75.103.62:5895/0.m3u8" #punchtv #"rtsp://69.75.103.62:5897/live/1" #"https://stream.punchflix.net:444/RoscoesLive/tracks-v3a1/mono.m3u8"
# "https://stream.punchflix.net:444/RoscoesLive/embed.html"
Oo = "https://www.punchtvstudios.com"
I1ii11iIi11i = "plugin://plugin.video.youtube/channel/UCoeBYXgTn90ZJalM4ntEQRQ/"

IiII = "https://shop.punchtvstudios.com/"
iI1Ii11111iIi = "https://www.punchtvstudios.com/invest/"
i1i1II = "https://PunchFlix.com"


def o0oOoO00o ( ) :
 i1 ( o0OoOoOO00 , '' , 0 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]---------------------------------------[/COLOR]" , '' , 0 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]Watch Live[/COLOR]" , O0O , 1 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 plugintools . add_item (
 title = "[COLOR white]On Demand[/COLOR]" ,
 url = I1ii11iIi11i ,
 thumbnail = iIiiiI1IiI1I1 + 'logo.png' ,
 fanart = I11i ,
 folder = True )
 i1 ( "[COLOR white]---------------------------------------[/COLOR]" , '' , 0 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]PunchFlix[/COLOR]" , '' , 5 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]Go to website[/COLOR]" , '' , 2 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]Punch store[/COLOR]" , '' , 4 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]Invest[/COLOR]" , '' , 5 , iIiiiI1IiI1I1 + 'logo.png' , I11i )
 i1 ( "[COLOR white]Contact[/COLOR]" , '' , 3 , iIiiiI1IiI1I1 + 'logo.png' , I11i )

 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )

def oO0O0o0o0 ( ) :
 i1iIIII = xbmcgui . Dialog ( )
 i1iIIII . ok ( o0OoOoOO00 , "[COLOR white]Tel. [B](310)419-5914[/B]" , "Email.  [B]Contact@punchtvstudios.com[/B] [/COLOR]" , "\n                   [COLOR white][B]Website: www.punchtvstudios.com[/B][/COLOR]" )
 sys . exit ( 1 )

def i1iiIIiiI111 ( url ) :
 IIIiI11ii = webbrowser . open
 O000oo = xbmc . executebuiltin
 i1iIIi1 = lambda ii11iIi1I : xbmc . getCondVisibility ( str ( ii11iIi1I ) )
 iI111I11I1I1 = lambda ii11iIi1I : O000oo ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ii11iIi1I ) )
 OOooO0OOoo = 'System.Platform.Android'
 if i1iIIi1 ( OOooO0OOoo ) : iI111I11I1I1 ( url )
 else : IIIiI11ii ( url )

def IiIIIiI1I1 ( url ) :
 xbmc . Player ( ) . play ( O0O )#plugintools.play_resolved_url(O0O)#

def i1 ( name , url , mode , iconimage , fanart , description = "" , isFolder = True , background = None ) :
 ooOoo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OooO0 = sys . argv [ 0 ] + "?url=None&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 print name . replace ( '-[US]' , '' ) . replace ( '-[EU]' , '' ) . replace ( '[COLOR yellow]' , '' ) . replace ( '[/COLOR]' , '' ) . replace ( ' (G)' , '' ) + '=' + OooO0
 II11iiii1Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 II11iiii1Ii . setProperty ( "Fanart_Image" , fanart )
 II11iiii1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 II11iiii1Ii . setProperty ( 'IsPlayable' , 'true' )
 xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOoo0O , listitem = II11iiii1Ii , isFolder = isFolder )

def oOOO00o ( ) :
 O0O00o0OOO0 = int ( sys . argv [ 1 ] )
 xbmcplugin . setContent ( O0O00o0OOO0 , 'modes' )
 if 27 - 27: O0 % i1IIi * I1i1iI1i + i11iIiiIii + OoooooooOO * i1IIi
 for o0oo0o0O00OO in modes :
  o0oO = os . path . join ( I1i1iii , 'logos' , o0oo0o0O00OO [ 'icon' ] )
  i1iiI11I = xbmcgui . ListItem ( o0oo0o0O00OO [ 'name' ] , iconImage = o0oO )
  iiii = sys . argv [ 0 ] + '?mode=' + str ( o0oo0o0O00OO [ 'id' ] )
  xbmcplugin . addDirectoryItem ( handle = O0O00o0OOO0 , url = iiii , listitem = i1iiI11I , isFolder = True )
 xbmcplugin . endOfDirectory ( O0O00o0OOO0 )

def OOOO ( mode ) :
 OOO00 = int ( sys . argv [ 1 ] )
 xbmcplugin . setContent ( OOO00 , 'streams' )
 logging . warning ( 'mode show_streams!!!! %s' , mode )
 for iiiiiIIii in streams [ str ( mode ) ] :
  logging . debug ( 'STREAM HERE!!! %s' , iiiiiIIii [ 'name' ] )
  o0oO = os . path . join ( I1i1iii , 'logos' , iiiiiIIii [ 'icon' ] )
  i1iiI11I = xbmcgui . ListItem ( iiiiiIIii [ 'name' ] , iconImage = o0oO )
  xbmcplugin . addDirectoryItem ( handle = OOO00 , url = iiiiiIIii [ 'url' ] , listitem = i1iiI11I )
 xbmcplugin . endOfDirectory ( OOO00 )

def play_vod(url):
	urllink = url
	plugintools.play_resolved_url(urllink)

	time.sleep(3)
        if xbmc.Player().isPlaying() == False:
                xbmc.executebuiltin('Notification(Channel Unavailable at this moment,,10000,)')


def II111ii1II1i ( ) :
 OoOo00o = [ ]
 o0OOoo0OO0OOO = sys . argv [ 2 ]
 if len ( o0OOoo0OO0OOO ) >= 2 :
  iI1iI1I1i1I = sys . argv [ 2 ]
  iIi11Ii1 = iI1iI1I1i1I . replace ( '?' , '' )
  if ( iI1iI1I1i1I [ len ( iI1iI1I1i1I ) - 1 ] == '/' ) :
   iI1iI1I1i1I = iI1iI1I1i1I [ 0 : len ( iI1iI1I1i1I ) - 2 ]
  Ii11iII1 = iIi11Ii1 . split ( '&' )
  OoOo00o = { }
  for Oo0O0O0ooO0O in range ( len ( Ii11iII1 ) ) :
   IIIIii = { }
   IIIIii = Ii11iII1 [ Oo0O0O0ooO0O ] . split ( '=' )
   if ( len ( IIIIii ) ) == 2 :
    OoOo00o [ IIIIii [ 0 ] . lower ( ) ] = IIIIii [ 1 ]
 return OoOo00o
def IIiI1I ( field ) :
 def O00Oo000ooO0 ( obj ) :
  return obj [ field ] . lower ( )

 return O00Oo000ooO0
iIIIi1 = xbmcaddon . Addon ( )
I1i1iii = xbmc . translatePath ( iIIIi1 . getAddonInfo ( 'path' ) )

IiI11iII1 = II111ii1II1i ( )
o0oo0o0O00OO = None
logging . warning ( 'PARAMS!!!! %s' , IiI11iII1 )

try :
 o0oo0o0O00OO = IiI11iII1 [ 'mode' ]
except :
 pass

logging . warning ( 'ARGS!!!! sys.argv %s' , sys . argv )
if o0oo0o0O00OO == None :
 o0oOoO00o ( )
elif o0oo0o0O00OO == "0" :
 pass
elif o0oo0o0O00OO == "1" :
 IiIIIiI1I1 ( O0O )#play_vod(O0O )#
elif o0oo0o0O00OO == "2" :
 i1iiIIiiI111 ( Oo )

elif o0oo0o0O00OO == "3" :
 oO0O0o0o0 ( )
elif o0oo0o0O00OO == "4" :
 i1iiIIiiI111 ( IiII )
elif o0oo0o0O00OO == "5" :
 i1iiIIiiI111 ( iI1Ii11111iIi )

elif o0oo0o0O00OO == "5" :
 i1iiIIiiI111 ( PunchFlix ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

def play_vod(url):
	urllink = url
	plugintools.play_resolved_url(urllink)

	time.sleep(3)
        if xbmc.Player().isPlaying() == False:
                xbmc.executebuiltin('Notification(Channel Unavailable at this moment,,10000,)')

