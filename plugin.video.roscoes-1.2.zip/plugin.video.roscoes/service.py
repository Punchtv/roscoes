import os
import time
import xbmc, xbmcgui,xbmcaddon
import datetime
import urllib2
#from resources.modules.utils import log
try:
	import simplejson as json
except:
	 print('Plugin Error', 'simplejson import error: limited functionality')
	 pass

import threading
from urllib2 import urlopen, URLError, HTTPError, Request
import urllib

Addon = xbmcaddon.Addon(id='plugin.video.roscoes')


PATH = xbmc.translatePath(Addon.getAddonInfo('profile'))
ADDON_PATH = xbmc.translatePath(Addon.getAddonInfo('path'))

CHECK_INTERVAL = 120
SUBCHECK_INTERVAL = 3600
DIALOG_INTERVAL = 21600

__settings__   = xbmcaddon.Addon(id='plugin.video.roscoes')
dialog = xbmcgui.Dialog()
def init():
    global activity_info


def app_active():
	while not xbmc.abortRequested:
                if xbmc.Player().isPlaying():
                        videof = xbmc.Player().getPlayingFile()
                        xbmc.log(' videeo playing : %s' %videof)
                        if "0.m3u8" in videof  :
                                 __settings__.setSetting('livetv','true')
                        else : __settings__.setSetting('livetv','false')
                #videof = xbmcgetPlayingFile()
                else :
                        if __settings__.getSetting('livetv') == 'true' :
                                xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&url=http://69.75.103.62:5895/0.m3u8)')
                                xbmc.log(' video  reload playing : %s' %videof)
                        
		xbmc.log('Sent activity info for SID(%s). Sleeping for 120 seconds.' % 'roscoes')
		for i in range(0, 120):
			time.sleep(1)
			reload(threading)
			if xbmc.abortRequested:
				break

def run():

		activity_info = threading.Thread(target=app_active)
		activity_info.start()
		xbmcgui.Window(10000).setProperty('My_Service_Running', 'True')


		while not xbmc.abortRequested:
			#xbmc.log('Sent activity info for SID(%s). Sleeping for 120 seconds.' % xbmcaddon.Addon('plugin.video.roscoes'))

			try:
				
                                        
				if xbmc.abortRequested:
					break
			except:
				print('>>> traceback <<<')
				import traceback; traceback.print_exc()
				print ('>>> end of traceback <<<')




def log(text):
	xbmc.log('PunchTV msg: %s' % text)

if __name__ == "__main__":
	xbmc.log('service started')
	__settings__.setSetting('livetv','false')

	run()
	xbmc.log('service exited')
